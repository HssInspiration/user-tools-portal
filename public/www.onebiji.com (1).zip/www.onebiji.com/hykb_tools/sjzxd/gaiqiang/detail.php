<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
<title>三角洲行动改枪台,三角洲行动改枪,三角洲模拟改枪</title>
<meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0,user-scalable=no"/>
<meta name="keywords" content="三角洲行动改枪，改枪台，三角洲行动模拟改枪">
<meta name="description" content="三角洲行动x快爆改枪台为你提供三角洲行动模拟改枪，打造顶级枪械作战！好游快爆APP">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<meta name="full-screen" content="yes"/>
<meta name="x5-fullscreen" content="true"/>
<link href="https://res.3839pic.com/kuaibao/dialog8/css/dialog-base.css?v100" rel="stylesheet" type="text/css"><link href="./static/v1/css/style.css?v13" type="text/css" rel="stylesheet">
<link href="./static/v1/css/swiper.min.css?v13" type="text/css" rel="stylesheet">
<script src="./static/v1/js/FontSize.js?v13"></script>
<script type="text/javascript" src="//res.3839pic.com/kuaibao/js/hykb_tools_utf8.js" charset="utf-8"></script><script>
    var INDEX_URL = 'https://www.onebiji.com/hykb_tools/sjzxd/gaiqiang/index.php?immgj=0';
    var DETAIL_URL = 'https://www.onebiji.com/hykb_tools/sjzxd/gaiqiang/detail.php';
    var MY_URL = 'https://www.onebiji.com/hykb_tools/sjzxd/gaiqiang/my.php';
    var GAI_URL = 'https://www.onebiji.com/hykb_tools/sjzxd/gaiqiang/gai.php';
    var _img_dm = 'https://www.onebiji.com/71acg';
    SKIN = './static/v1';
</script></head>
<body>
<div class="detail share-img" id="CanvasBoxDiv">
    <div class="head-img2">
        <img src="./static/v1/images/head2.png" alt="" srcset="">
    </div>
    <div class="detail-pannel">
        <div class="gun">
            <div class="left">
                <p class="type-name">狙击步枪</p>
                <img class="gun-img" src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_cc5f951b3755e367657f23189a6f7da4.png" alt="" srcset="">
                <p class="name">SV-98狙击步枪</p>
                <div class="coin">参考价值<span class="coin-tag"></span>231,549</div>
            </div>
            <div class="right">
                <div class="attribute">
                                            <div class="item">
                            <div class="top">
                                <span class="name">基础伤害</span><span class="num ">55</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 56%;">
                                                                    </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">优势射程</span><span class="num add">159(+9)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 100%;">
                                    <div class="add" style="width:0.114rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">后坐力控制</span><span class="num add">58(+3)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 56%;">
                                    <div class="add" style="width:0.057rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">操控速度</span><span class="num minus">19(-31)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 50%;">
                                    <div class="minus" style="width:0.589rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">据枪稳定性</span><span class="num ">50</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 50%;">
                                                                    </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">腰际射击精度</span><span class="num ">26</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 26%;">
                                                                    </div>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
        <div class="detail-pars">
            <div class="detail-title">具体改装</div>
        </div>
        <div class="list3">
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">枪口</span>
                        <img src="https://www.onebiji.com/71acg/sykb~bbs/pc/1724756994447" alt="">
                    </div>
                    <p class="name">
                        共鸣狙击枪消音器                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">瞄准镜</span>
                        <img src="https://www.onebiji.com/71acg/sykb~bbs/pc/1724755908784" alt="">
                    </div>
                    <p class="name">
                        6/12神射手变倍狙击镜                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">枪管</span>
                        <img src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_9c1d460a8a4c5234053c99864315ba91.png" alt="">
                    </div>
                    <p class="name">
                        R93长枪管                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">侧瞄具</span>
                        <img src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_0946140d7a9d096ec6d9dc4786136e71.png" alt="">
                    </div>
                    <p class="name">
                        侧置全景红点瞄准镜                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">右导轨</span>
                        <img src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_b1e7971cd4409b51297efccdf27ce144.png" alt="">
                    </div>
                    <p class="name">
                        PEQ-2红色激光镭指                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">左导轨</span>
                        <img src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_b1e7971cd4409b51297efccdf27ce144.png" alt="">
                    </div>
                    <p class="name">
                        PEQ-2红色激光镭指                    </p>
                </div>
                            <div class="item">
                    <div class="img-wrapper">
                        <span class="type">上导轨</span>
                        <img src="https://www.onebiji.com/71acg/whd~hykb/comm/hd_admin_upload_2982_38fcda2c9d1203369989fc0612dc8004.png" alt="">
                    </div>
                    <p class="name">
                        LA-3C绿色激光镭指                    </p>
                </div>
                    </div>
                <div class="share-qrcode">
            <img src="./static/v1/images/share_qrcode.png" alt="" srcset="">
        </div>
    </div>
</div>
<!-- 展示的面板 -->
<div class="detail">
    <div class="info">
        <p class="name">零号大坝狙仔配装</p>
        <div class="lables">
            <div class="item"><span class="sl1"></span> 萌新推荐</div><div class="item"><span class="sl2"></span> 性价比</div><div class="item"><span class="sl6"></span> 零号大坝</div>        </div>
        <div class="user-box">
            <a href="javascript:;" onclick="ACT.toPersonCenter(131784874)">
                <img class="via lazyload" data-src="//imga.3839.com/131784874?t=1713335041" alt="">
                <span class="nick">冰淇淋后遗症</span>
            </a>
            <img class="medal lazyload" data-src="https://img.71acg.net/sykb~bbs/default/20241126/1659048840034" alt="嗷呜村感染狼">            <span class="line"></span>
            <span class="time">09-13</span>
            <a href="javascript:;" class="btn follow" data-uid="131784874">关注</a>
        </div>
    </div>
    <div class="detail-pannel">
        <div class="gun">
            <div class="left">
                <p class="type-name">狙击步枪</p>
                <img class="gun-img lazyload" data-src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_cc5f951b3755e367657f23189a6f7da4.png" alt="" srcset="">
                <p class="name">SV-98狙击步枪</p>
                <div class="coin">参考价值<span class="coin-tag"></span>231,549</div>
            </div>
            <div class="right">
                <div class="attribute">
                                            <div class="item">
                            <div class="top">
                                <span class="name">基础伤害</span><span class="num ">55</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 56%;">
                                                                    </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">优势射程</span><span class="num add">159(+9)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 100%;">
                                    <div class="add" style="width:0.114rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">后坐力控制</span><span class="num add">58(+3)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 56%;">
                                    <div class="add" style="width:0.057rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">操控速度</span><span class="num minus">19(-31)</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 50%;">
                                    <div class="minus" style="width:0.589rem;"></div>                                </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">据枪稳定性</span><span class="num ">50</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 50%;">
                                                                    </div>
                            </div>
                        </div>
                                            <div class="item">
                            <div class="top">
                                <span class="name">腰际射击精度</span><span class="num ">26</span>
                            </div>
                            <div class="progress-wrapper">
                                <div class="progress" style="width: 26%;">
                                                                    </div>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
        <div class="detail-pars">
            <div class="detail-title">
                具体改装
            </div>
        </div>
        <div class="list3" id="gai_peijian_list">
                            <div class="item" data-id="178">
                    <div class="img-wrapper">
                        <span class="type">枪口</span>
                        <img src="https://img.71acg.net/sykb~bbs/pc/1724756994447" alt="共鸣狙击枪消音器">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 53,302                            </div>
                                            </div>
                    <p class="name">
                        共鸣狙击枪消音器                    </p>
                </div>
                            <div class="item" data-id="143">
                    <div class="img-wrapper">
                        <span class="type">瞄准镜</span>
                        <img src="https://img.71acg.net/sykb~bbs/pc/1724755908784" alt="6/12神射手变倍狙击镜">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 73,212                            </div>
                                            </div>
                    <p class="name">
                        6/12神射手变倍狙击镜                    </p>
                </div>
                            <div class="item" data-id="269">
                    <div class="img-wrapper">
                        <span class="type">枪管</span>
                        <img src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_9c1d460a8a4c5234053c99864315ba91.png" alt="R93长枪管">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 10,000                            </div>
                                            </div>
                    <p class="name">
                        R93长枪管                    </p>
                </div>
                            <div class="item" data-id="285">
                    <div class="img-wrapper">
                        <span class="type">侧瞄具</span>
                        <img src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_0946140d7a9d096ec6d9dc4786136e71.png" alt="侧置全景红点瞄准镜">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 52,489                            </div>
                                            </div>
                    <p class="name">
                        侧置全景红点瞄准镜                    </p>
                </div>
                            <div class="item" data-id="28">
                    <div class="img-wrapper">
                        <span class="type">右导轨</span>
                        <img src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_b1e7971cd4409b51297efccdf27ce144.png" alt="PEQ-2红色激光镭指">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 28,933                            </div>
                                            </div>
                    <p class="name">
                        PEQ-2红色激光镭指                    </p>
                </div>
                            <div class="item" data-id="28">
                    <div class="img-wrapper">
                        <span class="type">左导轨</span>
                        <img src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_b1e7971cd4409b51297efccdf27ce144.png" alt="PEQ-2红色激光镭指">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 28,933                            </div>
                                            </div>
                    <p class="name">
                        PEQ-2红色激光镭指                    </p>
                </div>
                            <div class="item" data-id="27">
                    <div class="img-wrapper">
                        <span class="type">上导轨</span>
                        <img src="//img.71acg.net/whd~hykb/comm/hd_admin_upload_2982_38fcda2c9d1203369989fc0612dc8004.png" alt="LA-3C绿色激光镭指">
                                                    <div class="coin">
                                <span class="coin-tag"></span> 20,255                            </div>
                                            </div>
                    <p class="name">
                        LA-3C绿色激光镭指                    </p>
                </div>
                    </div>
            </div>
</div>
<div class="bottom-next">
    <a class="share action" id="share_btn" data-id="3">252</a>
    <a href="" class="star action collect" data-id="3">453</a>
    <a href="javascript:;" class="like action zan" data-id="3">1065</a>
</div>
<div class="share-mask" style="display: none;"></div>

<!--分享-->
<div class="pop step_div" id="shareDiv" style="display: none;">
    <div class="pop-share-wrapper">
        <img src="./static/v1/images/head2.png" alt="" id="shareImg">
    </div>
    <div class="bottom-pop">
        <p class="bottom-name">
            来#好游快爆#改枪台，打造个人专属枪械！
        </p>
        <div class="share-list">
            <a href="javascript:;" class="item download" id="clickSave">
                <img src="./static/v1/images/download.png" alt="" srcset="">
            </a>
            <a href="javascript:;" class="item" onclick="ACT.ShareOnlyPic('qq'); return false;">
                <img src="./static/v1/images/qq.png" alt="" srcset="">
            </a>
            <a href="javascript:;" class="item" onclick="ACT.ShareOnlyPic('weixin'); return false;">
                <img src="./static/v1/images/wechat.png" alt="" srcset="">
            </a>
            <a href="javascript:;" class="item" onclick="ACT.ShareOnlyPic('qzone'); return false;">
                <img src="./static/v1/images/zone.png" alt="" srcset="">
            </a>
            <a href="javascript:;" class="item" onclick="ACT.ShareOnlyPic('pengyouquan'); return false;">
                <img src="./static/v1/images/friend.png" alt="" srcset="">
            </a>
            <a href="javascript:;" class="item" onclick="ACT.ShareOnlyPic('weibo'); return false;">
                <img src="./static/v1/images/weibo.png" alt="" srcset="">
            </a>
        </div>
    </div>
</div>
<div style="width:6rem;display:none;" id="dialog_other_place_login">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28">你的账号已经在另外一台设备登录，如非本人操作请注意账号安全。</div>
            </div>
            <div class="dia-btn">
                <a class="bt1 dialog_other_place_login_close" href="">知道了</a>
                <a class="bt2" href="" onclick="window.activityInterface.switchToMine(); return false;">重新登录</a>
            </div>
        </div>
    </div>
</div>
<div style="width:6rem;display:none;" id="dialog_version">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28">本活动需要更新到最新版本快爆即可参与哦！<br>升级途径：首页<span class="cl-green">【我的】</span>- 右上角齿轮<span class="cl-green">【设置】</span>-检查新版本
                </div>
            </div>
            <div class="dia-btn">
                <a class="bt1 dialog_version_close" href="">好的</a>
                <a class="bt2" href="" onclick="window.activityInterface.toSetting(); return false;">去升级</a>
            </div>
        </div>
    </div>
</div>
<div class="dia v2" id="dialog_shuoming" style="display: none">
    <span class="dia-close dialog_shuoming_close"></span>
    <div class="dia-title">
        工具使用说明    </div>
    <div class="html-content">
        <p class="txt">
<img src="https://img.71acg.net/sykb~bbs/pc/1726818211564" alt="改枪">
</p>    </div>
</div>
<div style="width:6rem;display:none;" id="dialog_msg">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28 mt10" id="dialog_msg_info"></div>
            </div>
            <div class="dia-btn">
                <a class="bt1 dialog_msg_close" href="">好的</a>
            </div>
        </div>
    </div>
</div>
<div style="width:6rem;display:none;" id="dialog_record">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28 mt10">检测到上一次未完成改枪，是否返回上次改枪界面</div>
            </div>
            <div class="dia-btn">
                <a class="bt1 dialog_record_close" href="javascript:;" onclick="ACT.clearRecord();">否</a>
                <a class="bt2 dialog_record_close" href="javascript:;" onclick="ACT.loadRecord();">是</a>
            </div>
        </div>
    </div>
</div>

<div style="width:6rem;display:none;" id="dialog_back_queren">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28 mt10">即将返回工具箱，如需返回之前页面，请点击底部【上一步】<br>下次回来：【首页搜索——三角洲改枪】</div>
            </div>
            <div class="dia-btn">
                <a class="bt1 dialog_back_queren_close" href="">取消</a>
                <a class="bt2 dialog_back_queren_close" href="" onclick="ACT.toToolsList(1)">确定</a>
            </div>
        </div>
    </div>
</div>

<div style="width:6rem;display:none;" class="fixed-center" id="dialog_gai_ok">
    <div class="dialog-base dialog-center">
        <div class="inner">
            <div class="dia-con">
                <div class="dia-f28 mt10">方案创建成功，你的方案将在1个工作日内审核，审核通过后将在【首页/我的-我的发布】中展示。
                    <br>（预计将在24小时内审核通过）</div>
            </div>
            <div class="dia-btn">
                <a href="javascript:;" onclick="ACT.toMyPage(1);" class="dialog_gai_ok_close bt1">返回首页</a>
                <a href="javascript:;" onclick="ACT.makeImg();" class="dialog_gai_ok_close bt2 statBtn" data-stat-id="12">生成枪械卡</a>
            </div>
        </div>
    </div>
</div>

<!-- 弹窗遮罩 -->
<div class="create-dialog-mask"></div><div class="toast" id="dia_toast_msg"></div>
<script>
    var _PAGE_INDEX = 4;
    var _page_pram = {'page': 'detail', id:3};
</script>
<script type="text/javascript" id="js_arousal" charset="utf-8" src="//res.onebiji.com/kuaibao/js/comm/common_arousal_v1.js?v19" data-obj="{'btnShow':'0','isAuto':'1'}"></script>
<script type="text/javascript" src="//res.3839pic.com/kuaibao/js/jquery/1.8/jquery.js"></script>
<script type="text/javascript" src="./static/v1/js/lazysizes.min.js?v13"></script>
<script type="text/javascript" src="//res.onebiji.com/kuaibao/js/comm/matchios.js?v25"></script>
<script type="text/javascript" src="//res.onebiji.com/kuaibao/js/comm/base_v7.js?v11"></script>
<script type="text/javascript" src="//res.onebiji.com/kuaibao/js/comm/verify_v8.js?v65"></script>
<script type="text/javascript" src="./static/v1/js/jquery.cookie.js?v13"></script>
<script type="text/javascript" src="./static/v1/js/swiper.js?v13"></script>
<script type="text/javascript" src="./static/v1/js/lazysizes.min.js?v13"></script>
<script type="text/javascript" src="./static/v1/js/html2canvas.js"></script>
<script type="text/javascript" src="data.php?ac=peijian_list"></script>
<script type="text/javascript" src="./static/v1/js/base.js?v13"></script>
<script type="text/javascript" src="./static/v1/js/detail.js?v13"></script>
<script type="text/javascript" src="//newsimg.5054399.com/js/kbtj.js"></script>
</body>
</html>