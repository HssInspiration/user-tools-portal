var _bdhmProtocol = cnzz_protocol  = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write("<div style='display:none'>");
if(navigator.userAgent.match(/4399_sykb/i)){
	document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Febd65e862c4f8dfaaebf174e1ae0d2ba' type='text/javascript'%3E%3C/script%3E"));
}
else{
	document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Ff1fb60d2559a83c8fa1ee6125a352bd7' type='text/javascript'%3E%3C/script%3E"));
	document.write(unescape("%3Cspan id='cnzz_stat_icon_1000292083'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/q_stat.php%3Fid%3D1000292083' type='text/javascript'%3E%3C/script%3E"));
}
if("https:" == document.location.protocol){
	document.write("<img src='https://yxhhd2.5054399.com/static/kb.gif'/>");
}
else{
	document.write("<img src='http://www.yxhhdl.com/static/kb.gif'/>");
}
document.write("<\/div>");